# 8x8 dot-matrix MAX7219 display alfabet

In dit project laten we het alfabet letter voor letter op het 8x8 dot-matrix display zien, beginnend met alle HOOFDLETTERS en gevolgd door kleine letters.
